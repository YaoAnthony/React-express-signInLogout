import axios from "axios";
import setAuthorizationToken from "../utils/setAuthorization"
import { SET_CURRENT_USER } from "../setting/env"
import jwtDecode from "jwt-decode"

/**
 * 用于设置基础用户信息
 */
export const setCurrentuser = (user) =>{
    return{
        type : SET_CURRENT_USER,
        user
    }
}
/**
 * 用于删除储存在localstorage当中的item " jwtToken"
 */
export const logout = () =>{
    return dispatch =>{
        localStorage.removeItem("jwtToken") //删除token
        setAuthorizationToken(false) //登录设置为false
        dispatch(setCurrentuser({})) //设置user为基础用户信息
    }
}

/**
 * 通过axios连接数据库，如果用户登录成功，则将返回的token储存在localStorage当中
 */
export const userSigninRequest = (data) =>{
    return dispatch => {
        return axios.post("/api/signin", data).then( res =>{
            const token = res.data.token
            localStorage.setItem('jwtToken',token )
            setAuthorizationToken(token)
            dispatch(setCurrentuser(jwtDecode(token)))
        })
    }
}
