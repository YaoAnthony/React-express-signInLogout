const serverPath = 'http://localhost:9000';
// import { SERVER_PATH } from "./setting/env"
const { createProxyMiddleware } = require('http-proxy-middleware');


module.exports = function(app) {
    app.use(
        '/api',
        //secure: false,//是否验证htpps的安全证书，如果域名是https需要配置此项
        createProxyMiddleware({
            target: serverPath,
            changeOrigin: true,
        })
    );
};

