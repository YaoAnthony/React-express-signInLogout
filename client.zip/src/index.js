import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

//redux model 处理引用
import {createStore, applyMiddleware } from "redux"
//import { configureStore } from '@reduxjs/toolkit' //TODO : 等全部做完就更新成最新的store创建
import { composeWithDevTools } from 'redux-devtools-extension';
import { Provider } from 'react-redux';
import logger from "redux-logger" //debug套件
import thunk from "redux-thunk" //网络请求套件
import rootReducer from './reducers/index'; //reducer
import setAuthorizationToken from "./utils/setAuthorization"
import { setCurrentuser } from './actions/signInAction'; //登录action载入

import jwtDecode from "jwt-decode" //jwt token 解码

const root = ReactDOM.createRoot(document.getElementById('root'));
const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(logger, thunk)))

if(localStorage.jwtToken){ //如果当地storage存在jwt token，更新到redux当中
  setAuthorizationToken(localStorage.jwtToken) 
  store.dispatch(setCurrentuser(jwtDecode(localStorage.jwtToken)))
}

setAuthorizationToken(localStorage.jwtToken) //token
// const store = configureStore({
//   rootReducer,
//   middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger)
// })
root.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);


