import React from "react"
import FlashMessage from "./FlashMessage"
class FlashMessagesList extends React.Component{
    render() {
        return (
            <div className="container">
                <FlashMessage />
            </div>
        );
    }
}

export default FlashMessagesList