import React from "react"

/**
 * 提示
 */
class FlashMessage extends React.Component{
    render() {
        return (
            <div className="container">
                
            </div>
        );
    }
}

export default FlashMessage