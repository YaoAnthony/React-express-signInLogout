import React from 'react';
import css from './index.module.scss';
import { RiWechat2Line as Wechat } from 'react-icons/ri';
import {BsInstagram as Ins} from 'react-icons/bs'
import { RxDiscordLogo as Discord} from 'react-icons/rx'

export default function Footer(){
  return(
    <div className={css.footer}> 
      <ul className={css.wrapper}>
        <li className={`${css.icon} ${css.facebook}`}>
          <span className={css.tooltip}>Discord</span>
          <span><Discord /></span>
        </li>
        <li className={`${css.icon} ${css.wechat}`}>
          <span className={css.tooltip}>Wechat</span>
          <span><Wechat /></span>
        </li>
        <li className={`${css.icon} ${css.instagram}`}>
          <span className={css.tooltip}>Instagram</span>
          <span><Ins /></span>
        </li>
      </ul>
    </div>
  )
}