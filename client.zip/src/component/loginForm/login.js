import React from 'react';
import css from './index.module.scss';

import { RiWechat2Line as Wechat } from 'react-icons/ri';
import { ImGoogle } from "react-icons/im";
import { withRouter } from '../../actions/withRouter';

class SigninForm extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            username : "",
            password : "",
            errors : "",
            isLoading : false 
        }
    }

    //onchange function
    onChange = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        })
    }


    onSubmit = (e) => {
        e.preventDefault(); //let page stay when submit the form
        this.setState({ errors : {}, isLoading : true})
        this.props.signInActions.userSigninRequest(this.state).then(
            () => {this.props.navigate('/')},
            ({response}) => {this.setState({ errors : response.data, isLoading : false})}
        )
    }

    render() {
        const { errors, isLoading } = this.state
        return (
            <div className={css.app}>
                <form onSubmit={this.onSubmit}>
                    <h3>Login Here</h3>

                    <label htmlFor="username">Username</label>
                    <input type="text" placeholder="Username" name='username' value={this.state.username} onChange = {this.onChange} />
                    { errors.username && <span className={css.errorMessage}>{errors.username}</span>}
                    
                    <label htmlFor="password">Password</label>
                    <input type="password" placeholder="Password" name='password' onChange = {this.onChange} />
                    { errors.password && <span className={css.errorMessage}>{errors.password}</span>}
                    
                    { errors.form && <span className={css.errorMessage}>{errors.form}</span>}

                    <button disabled={ isLoading } type='submit'>Log In</button>

                    <div className={css.divider}>
                        <span className={css.line}></span>
                        <div className={css.divider_text}>Or</div>
                        <span className={css.line}></span>
                    </div>
                    <div className={css.social}>
                        <div className={css.go}><ImGoogle className={css.icon}/></div>
                        <div className={css.fb}><Wechat className={css.icon}/></div>
                    </div>
                </form>
            </div>
        );
    }
}

export default withRouter(SigninForm);