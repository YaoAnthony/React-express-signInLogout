// import React, { useContext, useEffect } from "react";
import css from './index.module.scss';
import { FiSearch } from "react-icons/fi"; //搜索图标
// import { FilterContext, FilterDispath } from "../Context/ContextFilter";
// import { useLocation } from "react-router-dom";

function SearchBar() {
  // const { state } = useContext(FilterContext);
  // const { dispath } = useContext(FilterDispath);

  // const location = useLocation();
  // const { pathname } = location;
  // // change The route search input is empty
  // useEffect(() => {
  //   dispath({ type: "SEARCH_KEYWORD", payload: "" });
  // }, [pathname]);

  // const searchKeywordHandler = (e) => {
  //   dispath({ type: "SEARCH_KEYWORD", payload: e.target.value });
  // };

  //  onChange={(e) => searchKeywordHandler(e)}
  return (
    <div className={css.searchBar_box}>
      <input
        type="text"
        placeholder="Searching ..."
      />
      <span><FiSearch /></span>
    </div>
  );
}


export default SearchBar;
