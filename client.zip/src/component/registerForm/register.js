import React from 'react';
import css from './index.module.scss';

import { RiWechat2Line as Wechat } from 'react-icons/ri';
import { ImGoogle } from "react-icons/im";
import { withRouter } from '../../actions/withRouter';
/**
 * Sign up
 */
class SignupForm extends React.Component {
    
    constructor(props){
        super(props)
        this.state = {
            username: "",
            password: "",
            passwordConf : "",
            errors : {},
            isLoading : false,
            isValid : false
        }
    }

    //onchange function
    onChange = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        })
    }

    //submit form
    onSubmit = (e) => {
        e.preventDefault(); //let page stay when submit the form
        this.setState({ errors:{},isLoading : true})

        if(this.state.password === this.state.passwordConf){
            this.props.signupActions.userSignupRequest(this.state).then(
                () => {this.props.navigate('/')}, //successful 
                ({ response }) => { this.setState({ errors : response.data, isLoading : false})}// fail
            )
        }else{
            alert("password is not same")
        }
    }

    checkUserExists = (e) =>{
        const field = e.target.name;
        const val = e.target.value;
        let isValid;
        if( val !== ""){
            this.props.signupActions.isUserExists(val).then( res=>{
                let errors = this.state.errors
                if(res.data[0]){
                    errors[field] = "用户名 " + val + " 以被他人注册";
                    isValid = true;
                }else{
                    errors[field] = ""
                    isValid = false
                }
                this.setState({ errors, isValid})
            })
        }
    }

    render() {
        const { errors , isLoading, isValid } = this.state;
        return (
            <div className={css.app}>
                <form onSubmit={this.onSubmit}>
                    <h3>Register Here</h3>
                    
                    <label htmlFor="username">Username</label>
                    <input type="text" placeholder="Username" name="username" onBlur={this.checkUserExists} value={this.state.username} onChange={this.onChange}/>
                    { errors.username && <span className={css.errorMessage}>{errors.username}</span>}

                    <label htmlFor="password">Password</label>
                    <input type="password" placeholder="Password" name="password" value={this.state.password} onChange={this.onChange}/>
                    { errors.password && <span className={css.errorMessage}>{errors.password}</span>}

                    <label htmlFor="password">Confirm Password</label>
                    <input type="password" placeholder="Password" name="passwordConf" value={this.state.passwordConf} onChange={this.onChange}/>
        
                    <button disabled = { isLoading || isValid } type='submit'>Register</button>


                    
                    <div className={css.divider}>
                        <span className={css.line}></span>
                        <div className={css.divider_text}>Or login from</div>
                        <span className={css.line}></span>
                    </div>
                    <div className={css.social}>
                        <div className={css.go}><ImGoogle className={css.icon}/></div>
                        <div className={css.fb}><Wechat className={css.icon}/></div>
                    </div>
                </form>
            </div>
        );
    }
}
export default withRouter(SignupForm);

// export default class SignupForm extends React.Component {
    
//     constructor(props){
//         super(props)
//         this.state = {
//             username: "",
//             password: "",
//             passwordConf : "",
//             errors : {},
//             isLoading : false
//         }
//     }

//     //onchange function
//     onChange = (e) => {
//         this.setState({
//             [e.target.name] : e.target.value
//         })
//     }

//     //submit form
//     onSubmit = (e) => {
//         // try{
//         //     let navigate = useNavigate();
//         // }catch(e){
//         //     console.log(e);
//         // }
//         e.preventDefault(); //let page stay when submit the form
        
//         this.setState({ errors:{},isLoading : true})
//         if(this.state.password === this.state.passwordConf){
//             this.props.signupActions.userSignupRequest(this.state).then(
//                 () => {//successful 
//                     try{
//                         // redirect("/")
//                         this.props.navigation.navigate('/')
//                     }catch(e){
//                         console.log(e)
//                     }
//                 }, 
//                 ({ response }) => { // fail
//                     this.setState({ errors : response.data,isLoading : false})
//                 }
//             )
//         }else{
//             alert("password is not same")
//         }
        
//     }

//     render() {
//         const { errors , isLoading } = this.state;
//         return (
//             <div className={css.app}>
//                 <form onSubmit={this.onSubmit}>
//                     <h3>Register Here</h3>
                    
//                     <label htmlFor="username">Username</label>
//                     <input type="text" placeholder="Username" name="username" value={this.state.username} onChange={this.onChange}/>
//                     { errors.username && <span className={css.errorMessage}>{errors.username}</span>}
    
//                     <label htmlFor="password">Password</label>
//                     <input type="password" placeholder="Password" name="password" value={this.state.password} onChange={this.onChange}/>
//                     { errors.password && <span className={css.errorMessage}>{errors.password}</span>}
//                     <label htmlFor="password">Confirm Password</label>
//                     <input type="password" placeholder="Password" name="passwordConf" value={this.state.passwordConf} onChange={this.onChange}/>
        
//                     <button disabled = {isLoading} type='submit'>Register</button>
//                     <div className={css.divider}>
//                         <span className={css.line}></span>
//                         <div className={css.divider_text}>Or login from</div>
//                         <span className={css.line}></span>
//                     </div>
//                     <div className={css.social}>
//                         <div className={css.go}><ImGoogle className={css.icon}/></div>
//                         <div className={css.fb}><Wechat className={css.icon}/></div>
//                     </div>
//                 </form>
//             </div>
//         );
//     }
// }

