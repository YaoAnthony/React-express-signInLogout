import React from 'react';
import css from './index.module.scss';
import { NavLink, Link } from "react-router-dom";
import iconAvatar from "./avatar/andy.jpg" //用于测试登录头像
import { connect } from "react-redux" // redux
import { withRouter } from '../../actions/withRouter'; //自制withRouter组件
import { logout } from '../../actions/signInAction'; //logout函数




class Header extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            userInfo : {
                name : this.props.auth.user.username,
                iconUrl : "./avatar/andy.jpg"
            }
        }

        console.log(this.state.userInfo.name);
    }
    GuestNav = (
        <ul>
            <li><NavLink to="/register">Register</NavLink></li>
            <li><NavLink to="/login">Login</NavLink></li>
        </ul>
    )
    
    LoginHeader = (
        <ul>
            <li><NavLink to="/register">Register</NavLink></li>
        </ul>
    )
    
    RegisterHeader = (
        <ul>
            <li><NavLink to="/login">Login</NavLink></li> 
        </ul>
    )

    UserNav = (userInfo) =>(
        <ul>
            <li>
                <div className={css.dropdown}>
                    <span>{userInfo.name}<img src={iconAvatar} alt="avator" /> </span>
                    <div className={css.drop}>
                        <ul>
                            <li className={css.dropItem}><span>My profile</span></li>
                            <li className={css.dropItem}><span>My Favorite</span></li>
                            <li className={css.dropItem}><span onClick={this.logout.bind(this)}>Log out</span></li>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    )

    logout(e){
        this.props.logout() //登出
        e.preventDefault()
    }

    render() {
        const { isAuthenticated } = this.props.auth; //获得验证
        const pathname = this.props.location.pathname; // 获得当前path 路径
        var Nav = this.GuestNav; //设置右侧nav路由
        if(isAuthenticated){
            switch(pathname){
                case '/' : Nav = this.UserNav(this.state.userInfo); break;
                default:   Nav = this.UserNav(this.state.userInfo);
            }
        }else{
            switch(pathname){
                case '/' : Nav = this.GuestNav; break;
                case '/login': Nav = this.LoginHeader; break;
                case '/register' : Nav = this.RegisterHeader; break;
                default:   Nav = this.GuestNav;
            }
        }

        return (
            <header>
                <div className={css.content}>
                    <Link className={css.logo} to="/">LOGO</Link>
                    <nav>{Nav}</nav>
                </div>
            </header>
        );
    }
}
/**
 * 载入验证信息
 */
const mapDispatchToProps = (state) =>{
    return {
        auth : state.auth
    }
}

export default withRouter(connect(mapDispatchToProps, { logout })(Header))