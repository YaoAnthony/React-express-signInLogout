import { combineReducers } from "redux";
import auth from "./auth"

// Root 
const rootReducer = combineReducers({
    auth
})

export default rootReducer