export const SERVER_PATH = "http://localhost:9000"
export const SET_CURRENT_USER = "SET_CURRENT_USER"