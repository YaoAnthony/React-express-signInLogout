import React from 'react';

export default function ErrorPage(){
    return(
        <div>
            你访问的页面不存在
        </div>
    )
}