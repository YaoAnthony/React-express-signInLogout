import css from './index.module.scss';
import React from 'react';
import axios from 'axios';

import { RiWechat2Line as Wechat } from 'react-icons/ri';
import { motion } from "framer-motion"
import { ImGoogle } from "react-icons/im";

// import logger from "redux-logger"
// import thunk from "redux-thunk"
// import {composeWithDevTools} from "redux-devtools-extension"
// import { configureStore , applyMiddleware } from "redux"
// import rootReducer from './../../reducers/index';
// const store = createStore()

axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/json';
const serverPath = 'http://localhost:8000';

/**
 * 实现了对python后端的申请
 */
export default class MainPage extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            name : "",
            age : 0
        }
    
        this.change = this.change.bind(this)
        this.write = this.write.bind(this)
        this.read = this.read.bind(this)
    }

    change(key, e){
        
        this.setState({
            [key] : e.target.value
        })
    }

    async write(e){
        let data = {...this.state}
        console.log(data);
        try{
            e.preventDefault()
            let res = await axios.post(`${serverPath}/write/`, data)
            console.log(res);
        }catch(err){
            console.log(err);
        }
    }

    async read(e){
        let params = {
            name : 'andy'
        }

        e.preventDefault()
        let res = await axios.get(`${serverPath}/read/`, {params});
        console.log(res)
    }

    render(){
        return(
            <motion.div 
                className={css.wrap}
                initial = {{opacity : 0}}
                animate = {{opacity : 1}}
                exit = {{opacity : 0}}
            >
                <App />
                <div  className={css.app}>
                    <form>
                        <h3>Test</h3>
                        name
                        <input onChange={(e) => (this.change('name', e))} />
                        <br />
                        age
                        <input onChange={(e) => (this.change('age', e))} />
                        <br />
                        <button onClick={this.write}>write</button>
                        <button onClick={this.read}>Read</button>
                    </form>
                </div>  
            </motion.div> 
        )
    }
}


function App(){
    return(
        <div className={css.app}>
            <form action="#" method='post'>
                <h3>Login Here</h3>

                <label htmlFor="username">Username</label>
                <input type="text" placeholder="Username" id="username" />

                <label htmlFor="password">Password</label>
                <input type="password" placeholder="Password" id="password" />

                <button>Log In</button>
                <div className={css.divider}>
                    <span className={css.line}></span>
                    <div className={css.divider_text}>Or</div>
                    <span className={css.line}></span>
                </div>
                <div className={css.social}>
                    <div className={css.go}><ImGoogle className={css.icon}/></div>
                    <div className={css.fb}><Wechat className={css.icon}/></div>
                </div>
            </form>
        </div>
    )
}

