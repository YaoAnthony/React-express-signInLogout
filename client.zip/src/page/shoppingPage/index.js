// import css from './index.module.scss';
import React from 'react';
import Footer from '../../component/Footer/index';


export default class Shopping extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            page : "MainPage"
        }
    }

    render(){
        return(
            <>
                <App />
                <Footer />
            </>
        )
    }
}


function App(){
    return(
        <>
            here is app
        </>
    )
}

