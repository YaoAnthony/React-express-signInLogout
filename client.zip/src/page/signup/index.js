import css from './index.module.scss';
import React from 'react';
import { motion } from "framer-motion"
import { connect } from "react-redux"
import { bindActionCreators } from 'redux';

import * as signupActions from "../../actions/signupActions"
import SignupForm from "../../component/registerForm/register"

class Register extends React.Component {

    render(){
        return(
            <motion.div 
                className={css.wrap}
                initial = {{opacity : 0}}
                animate = {{opacity : 1}}
                exit = {{opacity : 0}}
            >
                <SignupForm signupActions = {this.props.signupActions}/>  
            </motion.div> 
        )
    }
}

const mapDispatchToProps = (dispatch) =>{
    return {
        signupActions : bindActionCreators(signupActions, dispatch)
    }
}

export default connect(null,mapDispatchToProps)(Register)

