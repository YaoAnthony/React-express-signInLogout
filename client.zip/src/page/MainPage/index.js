import css from './index.module.scss';
import React from 'react';
import Footer from '../../component/Footer/index';
import { Link } from "react-router-dom";

import { motion } from "framer-motion"

export default class MainPage extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            page : "MainPage"
        }
    }

    render(){
        return(
            <motion.div 
                className={css.wrap}
                initial = {{opacity : 0}}
                animate = {{opacity : 1}}
                exit = {{opacity : 0}}
            >
                <App />     
                <Footer />
            </motion.div>
        )
    }
}

/**
 * 主界面直连shopping界面
 * @returns 
 */
function App(){
    return(
        <div className={css.app}>
            <div className={css.btn}>
                <Link className={css.linkBtn} to="/shopping">Go Shopping</Link>
            </div>
        </div>
    )
}

