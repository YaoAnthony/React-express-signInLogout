import css from './index.module.scss';
import { Component } from "react";

export default class App extends Component{

    render() {
        return (
             <div>
                Here is itemPage
             </div>
        );
    }
}