import css from './index.module.scss';
import React from 'react';
// import axios from 'axios';

import { RiWechat2Line as Wechat } from 'react-icons/ri';
import { motion } from "framer-motion"
import { ImGoogle } from "react-icons/im";
import { connect } from "react-redux";



/**
 * 这里测试非受控组件，同时测试使用express实现注册
 * 需要安装： http-proxy-middleware
 */
class MainPage extends React.Component {
    constructor(props){
        super(props);
        this.username = React.createRef();
        this.state = {
            name : "",
            age : 0,
            value : ""
        }

    }

    clickHandler = (e) =>{
        e.preventDefault()
        console.log(this.username.current)
    }

    render(){
        console.log(this.props)
        return(
            <motion.div 
                className={css.wrap}
                initial = {{opacity : 0}}
                animate = {{opacity : 1}}
                exit = {{opacity : 0}}
            >
                    <div className={css.app}>
                        <form >
                            <h3>Login Here</h3>

                            <label htmlFor="username">Username</label>
                            <input type="text" placeholder="Username" id="username" ref={this.username}/>

                            <label htmlFor="password">Password</label>
                            <input type="password" placeholder="Password" id="password" ref={this.username}/>

                            <button type='submit' onClick={this.clickHandler}>Log In</button>
                            <div className={css.divider}>
                                <span className={css.line}></span>
                                <div className={css.divider_text}>Or</div>
                                <span className={css.line}></span>
                            </div>
                            <div className={css.social}>
                                <div className={css.go}><ImGoogle className={css.icon}/></div>
                                <div className={css.fb}><Wechat className={css.icon}/></div>
                            </div>
                        </form>
                    </div>   
            </motion.div> 
        )
    }
}

const mapStateToProps = (state) =>{
    return{
        counter : state
    }
}



export default connect(mapStateToProps)(MainPage)