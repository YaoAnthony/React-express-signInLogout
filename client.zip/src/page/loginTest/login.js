import css from './index.module.scss';
import React from 'react';
import { motion } from "framer-motion"
import { connect } from "react-redux";
import { bindActionCreators } from 'redux';

import * as signinActions from "../../actions/signInAction"
import SigninForm from "../../component/loginForm/login"

class Login extends React.Component {
    render(){
        return(
            <motion.div 
                className={css.wrap}
                initial = {{opacity : 0}}
                animate = {{opacity : 1}}
                exit = {{opacity : 0}}
            >
                <SigninForm signInActions = {this.props.signInActions} />
                
            </motion.div> 
        )
    }
}

const mapDispatchToProps = (dispatch) =>{
    return {
        signInActions : bindActionCreators(signinActions, dispatch)
    }
}

export default connect(null,mapDispatchToProps)(Login)


