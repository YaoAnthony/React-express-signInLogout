import './global_setting.css';
import React from 'react';
import { 
  BrowserRouter, 
  Routes, 
  Route, 
  useLocation 
} from "react-router-dom";


import { AnimatePresence } from "framer-motion" //用于淡入淡出切换

//Route
import Header from './component/Header/index';
import MainPage from './page/MainPage/index';
import Login from './page/loginTest/login';
import Register from './page/signup/index';
import Shopping from './page/shoppingPage';


export default class App extends React.Component {

  render(){
    return(
      <div className="Fwrap">
        <BrowserRouter>
          <MyRoute />
        </BrowserRouter>
      </div>
      
    )
  }
}
/**
 * react-route-dom version : V6
 * @returns 
 */
function MyRoute(){
  const location = useLocation();
  return(
    <AnimatePresence >
      <Header />
      <Routes location={location} key ={location.pathname}>
        <Route path="/" exact element={<MainPage/>} />
        <Route path="/login" strict={true} element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/shopping" element={<Shopping />} />
      </Routes>
    </AnimatePresence>
  )
}