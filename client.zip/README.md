# E-Com website

here is website

# depandence

    redux
    react-redux
    redux-logger
    redux-devtools-extension
    redux-thunk
    npm install --save-dev redux-devtools-extension